package driver;

import io.github.bonigarcia.wdm.DriverManagerType;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import java.util.Collections;
import java.util.HashMap;

import static io.github.bonigarcia.wdm.DriverManagerType.*;
import static utils.Utils.*;

public class AppWeb extends Drivers{

    String sistemaOperacional;
    private String url;
    public static final String HEADLESS = "headless";
    public static final String BROWSER = "browser";

    /**
     * Construtor padrão da classe
     * @author Quality Assurance Team
     * @since 2019-09-30
     * */
    public AppWeb() {
        this.sistemaOperacional = System.getProperty("os.name").toLowerCase();
        this.url = getProperties("url");
    }

    /**
     * Método responsável pela inicialização do driver com base no parâmetro. Este método encapsula os métodos
     * setConfigurationDownload e de inicialização do driver que será utilizado nos testes.
     * @author Quality Assurance Team
     * @param driverManagerType Driver a ser utilizado na criação e execução dos testes
     * @since 2019-09-30
     * */
    public void setUpDriver(DriverManagerType driverManagerType, String headless) {
        if (getDriver() == null || getDriver().toString().contains("null")) {
            switch (driverManagerType) {
                case CHROME:
                    setConfigurationDownload(CHROME);
                    switch (headless) {
                        case HEADLESS:
                            initChromeHeadless();
                            break;
                        case BROWSER:
                            initChromeDriver();
                            break;
                    }
                    break;
                case FIREFOX:
                    setConfigurationDownload(FIREFOX);
                    initFirefoxDriver();
                    break;
                case IEXPLORER:
                    setConfigurationDownload(IEXPLORER);
                    initInternetExplorerDriver();
                    break;
                case EDGE:
                    setConfigurationDownload(EDGE);
                    initEdgeDriver();
                    break;
            }
        }
    }

    /**
     * Este método faz a inicialização do ChromeDriver e das propriedades necessárias para criação e execução dos testes.
     * @author Quality Assurance Team
     * @since 2019-09-30
     * */
    public void initChromeDriver() {
        HashMap<String, Object> chromePrefs = new HashMap<>();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("start-maximized", "--ignore-ssl-errors","–-no-sandbox","ignore-certicate-errors");
        options.addArguments("--disable-extensions");
        options.setExperimentalOption("useAutomationExtension", false);
        options.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
        chromePrefs.put("profile.default_content_settings.popups", 0);
        chromePrefs.put("download.prompt_for_download", false);
        chromePrefs.put("credentials_enable_service", false);
        options.setExperimentalOption("prefs", chromePrefs);
        setDriver(setUrl(new ChromeDriver(options)));
        setProcessDriverName(getProcessName(CHROME));
    }

    /**
     * Este método faz a inicialização do ChromeDriver Headless e das propriedades necessárias para criação e execução dos testes.
     * @author Quality Assurance Team
     * @since 2019-09-30
     * */
    public void initChromeHeadless() {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("window-size=1366,768","--disable-dev-shm-usage","--no-sandbox", "disable-extensions", "--ignore-ssl-errors", "disable-gpu", "headless");
        setDriver(setUrl(new ChromeDriver(options)));
        setProcessDriverName(getProcessName(CHROME));
    }

    /**
     * Este método faz a inicialização do IEDriver e das propriedades necessárias para criação e execução dos testes
     * @author Quality Assurance Team
     * @since 2019-09-30
     * */
    public void initInternetExplorerDriver() {
        WebDriverManager.iedriver().setup();
        DesiredCapabilities caps = DesiredCapabilities.internetExplorer();
        caps.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);
        InternetExplorerDriver internetExplorerDriver = new InternetExplorerDriver(caps);
        internetExplorerDriver.manage().window().maximize();
        setDriver(setUrl(internetExplorerDriver));
    }

    /**
     * Este método faz a inicialização do FirefoxDriver e das propriedades necessárias para criação e execução dos testes
     * @author Quality Assurance Team
     * @since 2019-09-30
     * */
    public void initFirefoxDriver() {
        WebDriverManager.firefoxdriver().setup();
        FirefoxOptions options = new FirefoxOptions();
        options.addPreference("browser.download.folderList", 2);
        options.addPreference("browser.download.manager.showWhenStarting", false);
        options.addPreference("browser.helperApps.neverAsk.saveToDisk", "application/octet-stream");
        options.addPreference("browser.helperApps.neverAsk.openFile", "");
        options.addPreference("browser.helperApps.alwaysAsk.force", false);
        options.addPreference("browser.download.manager.alertOnEXEOpen", false);
        options.addPreference("browser.download.manager.focusWhenStarting", false);
        options.addPreference("browser.download.manager.useWindow", false);
        options.addPreference("browser.download.manager.showAlertOnComplete", false);
        options.addPreference("browser.download.manager.closeWhenDone", true);
        options.addPreference("pdfjs.disabled", true);
        setDriver(setUrl(new FirefoxDriver(options)));
        setProcessDriverName(getProcessName(FIREFOX));
    }

    /**
     * Este método faz a inicialização do EdgeDriver
     * @author Quality Assurance Team
     * @since 2019-09-30
     * */
    public void initEdgeDriver() {
        WebDriverManager.edgedriver().setup();
        EdgeDriver edgeDriver = new EdgeDriver();
        edgeDriver.manage().window().maximize();
        setDriver(setUrl(edgeDriver));
    }

    /**
     * Este método carrega a URL a ser acessada durante os testes com base no arquivo de configuração padrão 'setup.properties'
     * @author Quality Assurance Team
     * @param driver Driver que carregará a URL
     * @since 2019-09-30
     * */
    private WebDriver setUrl(WebDriver driver){
        try {
            if (!url.isEmpty() && url != null) {
                driver.get(url);
            }
        }catch (Exception e){
            Assert.fail("Não foi possível carregar a url do arquivo de configuração");
        }
        return driver;
    }

    /**
     * Este metodo faz a inserção de uma imagem em formato base64 no extent report por meio de marcação HTML. Faz, também,
     * o encapsulamento do método takeScreeshot. Será usado quando utilizar JUnit Test.
     * @author Quality Assurance Team
     * @since 2019-09-30
     * */
    public static void quitDriver() {
        getDriver().quit();
        if (System.getProperty("os.name").toLowerCase().contains("windows")) {
            killProcess(getProcessDriverName());
        }
    }
}