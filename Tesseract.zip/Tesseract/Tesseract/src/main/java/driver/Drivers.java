package driver;

import cucumber.api.Scenario;
import io.github.bonigarcia.wdm.DriverManagerType;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;

import static utils.Utils.getProperties;

public abstract class Drivers {

    private static ThreadLocal<WebDriver> driver = new ThreadLocal<>();
    public static ThreadLocal<String> processDriverName = new ThreadLocal<>();
    public static ThreadLocal<Scenario> testScenario = new ThreadLocal<>();
    private static String pathDownload = getProperties("pathDownload");

    /**
     * Método get do nome do processo referente ao driver
     * @author Quality Assurance Team
     * @return processDriverName
     * @since 2019-09-30
     * */
    public static String getProcessDriverName() {
        return processDriverName.get();
    }

    /**
     * Método set do nome do processo referente ao driver
     * @author Quality Assurance Team
     * @param processDriverName Processo do driver a ser utilizado nos testes
     * @since 2019-09-30
     * */
    public static void setProcessDriverName(String processDriverName) {
        Drivers.processDriverName.set(processDriverName);
    }

    /**
     * Método get do driver
     * @author Quality Assurance Team
     * @return WebDriver
     * @since 2019-09-30
     * */
    public static WebDriver getDriver() {
        return driver.get();
    }

    /**
     * Método set do driver
     * @author Quality Assurance Team
     * @param driver Driver a ser utilizado em toda a execução dos testes
     * @since 2019-09-30
     * */
    public static void setDriver(WebDriver driver) {
        Drivers.driver.set(driver);
    }

    /**
     * Método responsável por efetuar a configuração do download do driver a ser utilizado na execução dos testes.
     * Todas as configurações são carregadas do arquivo padrão 'setup.properties'
     * @author Quality Assurance Team
     * @param driverManagerType Tipo de driver que será feito o download
     * @since 2019-09-30
     * */
    public static void setConfigurationDownload(DriverManagerType driverManagerType) {
        if (pathDownload.isEmpty()) {
            WebDriverManager.chromedriver().config().setTargetPath(
                    System.getProperty("user.dir") + "\\target\\download\\");
        } else {
            WebDriverManager.chromedriver().config().setTargetPath(pathDownload);
        }
        String webDriverVersion = getProperties("webdriverversion");
        if (driverManagerType.equals(DriverManagerType.CHROME)) {
            if (!webDriverVersion.isEmpty()) {
                WebDriverManager.chromedriver().config().setChromeDriverVersion(getProperties("webdriverversion"));
                WebDriverManager.chromedriver().setup();
            }
        } else if (driverManagerType.equals(DriverManagerType.EDGE)) {
            if (!webDriverVersion.isEmpty()) {
                WebDriverManager.edgedriver().config().setEdgeDriverVersion(getProperties("webdriverversion"));
                WebDriverManager.edgedriver().forceDownload().setup();
            }
        }
    }
}