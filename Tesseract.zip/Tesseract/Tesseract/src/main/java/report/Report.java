package report;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.cucumber.listener.Reporter;
import org.openqa.selenium.*;
import org.testng.Assert;

import static driver.Drivers.getDriver;

public class Report {

    /**
     * Este metodo encapsula a action sendKeys de uma instancia WebElement. E uma abordagem generica para utilizacao
     * sempre que for necessario envio de texto para um Web Elemento
     * @author Quality Assurance Team
     * @return base64 String
     * @since 2019-08-28
     * */
    public static String takeScreenshot() {
        return ((TakesScreenshot)getDriver()).getScreenshotAs(OutputType.BASE64);
    }

    /**
     * Este metodo faz a inserção de uma imagem em formato base64 no extent report por meio de marcação HTML. Faz, também,
     * o encapsulamento do método takeScreeshot. Será usado quando utilizar BDD com Cucumber.
     * @author Quality Assurance Team
     * @since 2019-08-28
     * */
    public static void appendToReport() {
        Reporter.addStepLog("<div align=\"right\"><ul class='screenshots right'><li><img data-featherlight=\"image\" href=\"data:image/png;base64, "
                + takeScreenshot() + "\"  src=\"data:image/png;base64, "
                + takeScreenshot() + "\" alt=\"Red dot\" width=\"5%\" /></img></li></ul></div>");
    }

    /**
     * Este metodo faz a inserção de uma imagem em formato base64 no extent report por meio de marcação HTML. Faz, também,
     * o encapsulamento do método takeScreeshot. Será usado quando utilizar JUnit Test.
     * @author Quality Assurance Team
     * @return HTML report
     * @since 2019-08-28
     * */
    public static String appendToJUnitReport() {
        return "<div align=\"left\"><ul style=\"margin: 0px 0px\" class='screenshots right' ><li><img data-featherlight=\"image\" href=\"data:image/png;base64, "
                + takeScreenshot() + "\"  src=\"data:image/png;base64, "
                + takeScreenshot() + "\" alt=\"Red dot\" width=\"8%\" /></img></li></ul>";
    }

    /**
     * Este metodo faz a inserção de uma imagem em formato base64 no extent report por meio de marcação HTML. Faz, também,
     * o encapsulamento do método appendToJUnitReport. Será usado quando utilizar JUnit Test.
     * @author Quality Assurance Team
     * @param scenario Passo do teste em que será inserido a imagem
     * @param message Titulo da imagem a ser inserida
     * @param screenshotRequired Flag que define se será ou não inserido imagem no relatório
     * @param status Status do passo do teste
     * @since 2019-08-28
     * */
    public static void reportJUnit(ExtentTest scenario, Status status, boolean screenshotRequired, String message) {
        if (screenshotRequired) {
            if (status.equals(Status.FAIL)) {
                scenario.log(status, message.concat(appendToJUnitReport()));
                Assert.fail(message);
            } else if (status.equals(Status.PASS)) {
                scenario.log(status, message.concat(appendToJUnitReport()));
            }
        } else {
            if (status.equals(Status.FAIL)) {
                scenario.log(status, message);
                Assert.fail(message);
            } else if (status.equals(Status.PASS)) {
                scenario.log(status, message);
            }
        }
    }

    /**
     * Este metodo faz a inserção de imagem em base64 no extent report. Além da inserção da imagem, ele circula um elemento
     * para validação.
     * @author Quality Assurance Team
     * @param element Elemento que aparecerá circulado em vermelho na imagem
     * @since 2019-08-28
     * */
    public static void appendToReportElementHighlight(WebElement element) {
        ((JavascriptExecutor) getDriver()).executeScript("arguments[0].style.border='3px solid red'", element);
        appendToReport();
        ((JavascriptExecutor) getDriver()).executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "");
    }
}