package utils;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import static driver.Drivers.getDriver;

public class ElementActions {

    /**
     * Este método retorna um elemento com base no By passado por parâmetro. Bem como respeita o timeout passado por parâmetro.
     * Caso o elemento não seja encontrado, o teste será interrompido.
     * @author Quality Assurance Team
     * @param by      Mapeamento do Web Elemento
     * @param timeout Tempo de espera pelo Web Elemento
     * @return WebElement
     * @since 2019-09-01
     */
    public static WebElement getElement(By by, int timeout) {
        WebElement element = new WebDriverWait(getDriver(), timeout).until(ExpectedConditions.elementToBeClickable(by));
        if (element == null) {
            Assert.fail("Elemento não encontrado na página: " + element);
        }
        return element;
    }

    /**
     * Este metodo encapsula a action click de uma instancia WebElement. E uma abordagem generica para utilizacao
     * sempre que for necessario clicar em um Web Elemento.
     * @param by      Mapeamento do Web Elemento
     * @param timeout Tempo de espera pelo Web Elemento
     * @author Quality Assurance Team
     * @since 2019-09-01
     */
    public static void click(By by, int timeout) {
        getElement(by, timeout).click();
    }

    /**
     * Este metodo encapsula a action sendKeys de uma instancia WebElement. E uma abordagem generica para utilizacao
     * sempre que for necessario envio de texto para um Web Elemento
     * @param by      Mapeamento do Web Elemento
     * @param timeout Tempo de espera pelo Web Elemento
     * @param text    Texto a ser enviado ao elemento
     * @author Quality Assurance Team
     * @since 2019-09-01
     */
    public static void sendKeys(By by, int timeout, String text) {
        WebElement element = getElement(by, timeout);
        element.click();
        element.clear();
        element.sendKeys(text);
    }

    /**
     * Este metodo faz uma verificação da existência de alerta por meio do tratamento de exceção. Basicamente, tenta
     * efetuar a troca de foco para um alerta e com base na exceção gerada ou não, retorna um boolean
     * @author Quality Assurance Team
     * @return boolean
     * @since 2019-09-15
     */
    public static boolean isAlertPresent() {
        try {
            getDriver().switchTo().alert();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Este metodo força a parada da execucao do teste por x segundos
     * @param by      Mapeamento do Web Elemento
     * @param timeout Tempo de espera pelo Web Elemento
     * @author Quality Assurance Team
     * @since 2019-07-17
     */
    public static void waitElement(int timeout, By by) {
        int time = 0;
        boolean flag = false;
        while (time < timeout * 1000) {
            try {
                getDriver().findElement(by);
                flag = true;
                break;
            } catch (Exception e) {
                time = time + 100;
            }
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        if (time >= timeout * 1000 && !flag) {
            Assert.fail("Elemento não encontrado na página");
        }
    }
}