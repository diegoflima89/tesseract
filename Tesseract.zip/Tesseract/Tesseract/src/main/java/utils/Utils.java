package utils;

import io.github.bonigarcia.wdm.DriverManagerType;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.Assert;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

public class Utils {

    /**
     * Método responsável por capturar propriedades do arquivo de configuração padrão do framework de automação
     * @author Quality Assurance Team
     * @param propertie Propriedade que será carregada a partir do arquivo de configuração. O arquivo de configuração
     *                  tem o nome padrão de 'setup.properties'
     * @return propertie
     * @since 2019-09-01
     * */
    public static String getProperties(String propertie){
        try {
            InputStream inputStream = new FileInputStream("setup.properties");
            Properties properties = new Properties();
            properties.load(inputStream);
            return properties.getProperty(propertie);
        } catch (IOException e) {
            e.printStackTrace();
            Assert.fail("Erro ao carregar propriedade");
            return "";
        }
    }

    /**
     * Este método encerra um processo Windows
     * @param process Processo a ser encerrado por meio do comando Windows taskkill
     * @since 2019-08-28
     * */
    public static void killProcess(String process) {
        try {
            String line;
            Process p = Runtime.getRuntime().exec("tasklist.exe /fo csv /nh");
            BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));
            while ((line = input.readLine()) != null) {
                if (!line.trim().equals("")) {
                    if (line.substring(1, line.indexOf("\"", 1)).equalsIgnoreCase(process)) {
                        Runtime.getRuntime().exec("taskkill /F /IM " + line.substring(1, line.indexOf("\"", 1)));
                    }
                }
            }
            input.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Método auxiliar para captura do processo do driver que foi instanciado nos testes.
     * @author Quality Assurance Team
     * @param type Parâmetro DriverManagerType que indica qual driver está sendo utilizado.
     * @return processName
     * @since 2019-08-28
     * */
    public static String getProcessName(DriverManagerType type) {
        List<String> list = new ArrayList<>();
        switch (type) {
            case CHROME:
                 list = Arrays.asList(WebDriverManager.chromedriver().getBinaryPath().split("\\\\"));
                 break;
            case FIREFOX:
                list = Arrays.asList(WebDriverManager.firefoxdriver().getBinaryPath().split("\\\\"));
                break;
        }
        return list.get(list.size()-1);
    }

    /**
     * Este metodo faz o encapsulamento do método estático Thread.sleep.
     * @author Quality Assurance Team
     * @param timeout Tempo em segundos
     * @since 2019-09-30
     * */
    public static void sleep(int timeout) {
        try {
            Thread.sleep(timeout*1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}